document.addEventListener('DOMContentLoaded', function() {
    const sinhVienForm = document.getElementById('sinhVienForm');
    const maSVInput = document.getElementById('maSV');
    const hoTenInput = document.getElementById('hoTen');
    const emailInput = document.getElementById('email');
    const ngaySinhInput = document.getElementById('ngaySinh');
    const gioiTinhInput = document.getElementById('gioiTinh');
    const btnThem = document.getElementById('btnThem');
    const btnCapNhat = document.getElementById('btnCapNhat');
    const btnHuy = document.getElementById('btnHuy');
    const bangSinhVienBody = document.querySelector('#bangSinhVien tbody');
    const thongBaoDiv = document.getElementById('thongBao');

    const errorMaSV = document.getElementById('errorMaSV');
    const errorHoTen = document.getElementById('errorHoTen');
    const errorEmail = document.getElementById('errorEmail');
    const errorNgaySinh = document.getElementById('errorNgaySinh');

    let selectedRow = null;

    function hienThiThongBaoChung(message, type = 'success') {
        thongBaoDiv.textContent = message;
        thongBaoDiv.className = 'thong-bao';
        thongBaoDiv.classList.add(`thong-bao-${type}`);
        thongBaoDiv.style.display = 'block';

        thongBaoDiv.style.animation = 'none';
        thongBaoDiv.offsetHeight;
        thongBaoDiv.style.animation = 'fadeInOut 3s forwards';
    }

    function showInputError(element, message) {
        element.textContent = message;
    }

    function clearInputError(element) {
        element.textContent = '';
    }

    function clearAllInputErrors() {
        clearInputError(errorMaSV);
        clearInputError(errorHoTen);
        clearInputError(errorEmail);
        clearInputError(errorNgaySinh);
    }

    function resetForm() {
        sinhVienForm.reset();
        clearAllInputErrors();
        
        btnThem.style.display = 'inline-block';
        btnCapNhat.style.display = 'none';
        btnHuy.style.display = 'none';
        selectedRow = null;
        maSVInput.focus();
    }

    function validateInput(maSV, hoTen, email, ngaySinh) {
        let isValid = true;
        clearAllInputErrors();

        if (maSV.trim() === '') {
            showInputError(errorMaSV, 'Mã Sinh Viên không được để trống!');
            isValid = false;
        }

        if (hoTen.trim() === '') {
            showInputError(errorHoTen, 'Họ Tên không được để trống!');
            isValid = false;
        } else if (hoTen.trim().length < 3) {
            showInputError(errorHoTen, 'Họ Tên phải có ít nhất 3 ký tự!');
            isValid = false;
        }

        const emailRegex = /^\S+@\S+\.\S+$/;
        if (email.trim() === '') {
            showInputError(errorEmail, 'Email không được để trống!');
            isValid = false;
        } else if (!emailRegex.test(email.trim())) {
            showInputError(errorEmail, 'Email không hợp lệ!');
            isValid = false;
        }

        if (ngaySinh.trim() === '') {
            showInputError(errorNgaySinh, 'Ngày Sinh không được để trống!');
            isValid = false;
        }

        return isValid;
    }

    sinhVienForm.addEventListener('submit', function(e) {
        e.preventDefault();

        const maSV = maSVInput.value.trim();
        const hoTen = hoTenInput.value.trim();
        const email = emailInput.value.trim();
        const ngaySinh = ngaySinhInput.value;
        const gioiTinh = gioiTinhInput.value;

        if (!validateInput(maSV, hoTen, email, ngaySinh)) {
            return;
        }
        
        if (selectedRow === null) {
            const existingRows = bangSinhVienBody.querySelectorAll('tr');
            for (let i = 0; i < existingRows.length; i++) {
                if (existingRows[i].cells[0].textContent === maSV) {
                    hienThiThongBaoChung('Mã Sinh Viên đã tồn tại. Vui lòng nhập mã khác!', 'error');
                    return;
                }
            }

            const newRow = bangSinhVienBody.insertRow();
            newRow.insertCell(0).textContent = maSV;
            newRow.insertCell(1).textContent = hoTen;
            newRow.insertCell(2).textContent = email;
            newRow.insertCell(3).textContent = ngaySinh;
            newRow.insertCell(4).textContent = gioiTinh;

            const actionsCell = newRow.insertCell(5);
            actionsCell.innerHTML = `
                <button class="btn-sua">Sửa</button>
                <button class="btn-xoa">Xóa</button>
            `;
            
            newRow.cells[0].setAttribute('data-label', 'Mã SV:');
            newRow.cells[1].setAttribute('data-label', 'Họ Tên:');
            newRow.cells[2].setAttribute('data-label', 'Email:');
            newRow.cells[3].setAttribute('data-label', 'Ngày Sinh:');
            newRow.cells[4].setAttribute('data-label', 'Giới Tính:');
            newRow.cells[5].setAttribute('data-label', 'Hành Động:');

            hienThiThongBaoChung('Thêm sinh viên thành công!', 'success');
        } else {
            selectedRow.cells[0].textContent = maSV;
            selectedRow.cells[1].textContent = hoTen;
            selectedRow.cells[2].textContent = email;
            selectedRow.cells[3].textContent = ngaySinh;
            selectedRow.cells[4].textContent = gioiTinh;
            
            hienThiThongBaoChung('Cập nhật sinh viên thành công!', 'success');
        }
        resetForm();
    });

    bangSinhVienBody.addEventListener('click', function(e) {
        if (e.target.classList.contains('btn-xoa')) {
            if (confirm('Bạn có chắc chắn muốn xóa sinh viên này không?')) {
                const rowToDelete = e.target.closest('tr');
                if (rowToDelete) {
                    rowToDelete.remove();
                    hienThiThongBaoChung('Xóa sinh viên thành công!', 'success');
                    if (selectedRow === rowToDelete) {
                        resetForm();
                    }
                }
            }
        }

        if (e.target.classList.contains('btn-sua')) {
            selectedRow = e.target.closest('tr');
            if (selectedRow) {
                maSVInput.value = selectedRow.cells[0].textContent;
                hoTenInput.value = selectedRow.cells[1].textContent;
                emailInput.value = selectedRow.cells[2].textContent;
                ngaySinhInput.value = selectedRow.cells[3].textContent;
                gioiTinhInput.value = selectedRow.cells[4].textContent;

                clearAllInputErrors();

                btnThem.style.display = 'none';
                btnCapNhat.style.display = 'inline-block';
                btnHuy.style.display = 'inline-block';
            }
        }
    });

    btnCapNhat.addEventListener('click', function() {
        sinhVienForm.dispatchEvent(new Event('submit', { cancelable: true }));
    });

    btnHuy.addEventListener('click', function() {
        resetForm();
        hienThiThongBaoChung('Đã hủy thao tác cập nhật.', 'info');
    });

    btnThem.style.display = 'inline-block';
    btnCapNhat.style.display = 'none';
    btnHuy.style.display = 'none';
});